/**
* @file course.c
* @author Himasha Karunathilake
* @date 2022-02-11
* @brief Demonstrates the functions used to enroll students in a course, print course info, 
*        find the top student, and find the passing students
*/
#include "course.h"
#include <stdlib.h>
#include <stdio.h>

/**
* Function enrolls a student in a course
*
* @param course (a pointer of type Course)
* @param student (a pointer of type Student)
* @return nothing 
*/
void enroll_student(Course *course, Student *student)
{
  course->total_students++;
  if (course->total_students == 1) 
  {
    course->students = calloc(1, sizeof(Student));  //allocate space for one student in the course when only 1 total student
  }
  else 
  {
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); //reallocate space for more students when more than 1 total student
  }
  course->students[course->total_students - 1] = *student;  //add student to dynamic array of students in the course
}

/**
* Function prints the name, code, and total students in a course
*
* @param course (a pointer of type Course)
* @return nothing 
*/
void print_course(Course* course)
{
  // prints various information about the course
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  for (int i = 0; i < course->total_students; i++) //for loop prints the info of students in the course
    print_student(&course->students[i]);
}

/**
* Function finds the top student in a course
*
* @param course (a pointer of type Course)
* @return Student* (pointer of type Student) 
*/

Student* top_student(Course* course)
{
  if (course->total_students == 0) return NULL;
 
  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];
 
 // for loop goes through the students in a course and finds student with highest average 
  for (int i = 1; i < course->total_students; i++)
  {
    student_average = average(&course->students[i]);
    if (student_average > max_average) 
    {
      max_average = student_average;  
      student = &course->students[i]; //if student's average is greater than max average, then student is top student
    }   
  }

  return student;
}

/**
* Function finds the number of passing students and generates a dynamic array of these students 
*
* @param course (a pointer of type Course)
* @param total_passing (a pointer of type int)
* @return Student* (a dynamic array of type Student) 
*/

Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  
  // for loop calculates the number of students with a passing average
  for (int i = 0; i < course->total_students; i++) 
    if (average(&course->students[i]) >= 50) count++;
  
  passing = calloc(count, sizeof(Student)); //allocates space for students who have passed for a dynamic array of Students

  int j = 0;
  // for loop puts students who have passed into a dynamic array called passing if their average is greater than 50
  for (int i = 0; i < course->total_students; i++)
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }

  *total_passing = count; //number of passing students

  return passing; //returns passing students
}