/**
* @mainpage Course and Student function demonstration
*
* The course and student function demonstration shows how multiple functions in the course and student libraries work,
* including : 
* - enrolling students in a course
* - retrieving and printing the top student
* - finding and printing the passing students
*
* @file main.c
* @author Himasha Karunathilake
* @date 2022-02-11
* @brief Demonstrates the libraries used for creating courses with students
* 
*/
#include <stdlib.h> 
#include <stdio.h>
#include <string.h>
#include "time.h"
#include "course.h"

/**
* Main function generates 20 random students for a course and displays information using functions from the course 
* library which also includes the student library
* 
*/

int main()
{
  // Initializes the random number generator
  srand((unsigned) time(NULL));

  //Calloc is used in this line to dynamically allocate 1 element of the Course type from the struct in course.h
  Course *MATH101 = calloc(1, sizeof(Course));
  strcpy(MATH101->name, "Basics of Mathematics");
  strcpy(MATH101->code, "MATH 101");

  // for loop is used to generate and enroll 20 students into the MATH101 course using the functions from student.c and course.c
  for (int i = 0; i < 20; i++) 
    enroll_student(MATH101, generate_random_student(8));
  
  //prints the name,code, and total number of students in a course using function from course.c
  print_course(MATH101);

  Student *student;
  student = top_student(MATH101);
  printf("\n\nTop student: \n\n");
  print_student(student);     //prints the top student using function from student.c

  int total_passing;
  Student *passing_students = passing(MATH101, &total_passing);
  printf("\nTotal passing: %d\n", total_passing);
  printf("\nPassing students:\n\n");
  for (int i = 0; i < total_passing; i++) print_student(&passing_students[i]); /*for loop prints the student info of 
                                                                                students who have passed the course */
  
  return 0;
}