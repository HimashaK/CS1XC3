/**
* @file student.h
* @author Himasha Karunathilake
* @date 2022-02-11
* @brief Student library for managing students, with Student type definition and function definitions for adding grades
*        averages, printing student information, and generating random students
*/

/**
* Student type stores a student with fields first_name, last_name, id, grades, and num_grades
*
*/
typedef struct _student 
{ 
  char first_name[50]; /***< the student's first name */
  char last_name[50];  /***< the student's last name */
  char id[11];         /***< the student's id */
  double *grades;      /***< the student's grades */
  int num_grades;      /***< the number of grades */
} Student;

//function declarations
void add_grade(Student *student, double grade);
double average(Student *student);
void print_student(Student *student);
Student* generate_random_student(int grades); 
