/**
* @file student.c
* @author Himasha Karunathilake
* @date 2022-02-11
* @brief Demonstrates the functions used to add student grades, calculate averages, 
*        print student information, and generate random students
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "student.h"

/**
* Function adds a grade to a student's array of grades
*
* @param student (a pointer of type Student)
* @param grade (of type double)
* @return nothing 
*/

void add_grade(Student* student, double grade)
{
  student->num_grades++;
  if (student->num_grades == 1) student->grades = calloc(1, sizeof(double));  //allocate space for one grade
  else 
  {
    student->grades = 
      realloc(student->grades, sizeof(double) * student->num_grades); //re-allocate space for more grads when more than 1 grade
  }
  student->grades[student->num_grades - 1] = grade; //set grade to last element in dynamic double array of grades
}

/**
* Function calculates a student's average using their array of grades and number of grades
*
* @param student (a pointer of type Student)
* @return double (representing the student's average)
*/

double average(Student* student)
{
  if (student->num_grades == 0) return 0;

  double total = 0;
  for (int i = 0; i < student->num_grades; i++) total += student->grades[i]; //for loop adds student's grades to total
  return total / ((double) student->num_grades);  //returns the average calculated by dividing total by num of grades
}

/**
* Function prints the name, id, grades, and average of a student 
*
* @param student (a pointer of type Student)
* @return nothing 
*/

void print_student(Student* student)
{
  // prints various information about the student
  printf("Name: %s %s\n", student->first_name, student->last_name);
  printf("ID: %s\n", student->id);
  printf("Grades: ");
  for (int i = 0; i < student->num_grades; i++) //for loop prints the student's grades to 2 decimal places
    printf("%.2f ", student->grades[i]);
  printf("\n");
  printf("Average: %.2f\n\n", average(student));
}

/**
* Function generates a student with random information (name, id, grades)
*
* @param grades (of type int) - number of grades
* @return Student* (pointer of type Student) 
*/

Student* generate_random_student(int grades)
{
  char first_names[][24] = 
    {"Shahrzad", "Leonti", "Alexa", "Ricardo", "Clara", "Berinhard", "Denzel",
     "Ali", "Nora", "Malcolm", "Muhammad", "Madhu", "Jaiden", "Helena", "Diana",
     "Julie", "Omar", "Yousef",  "Amir", "Wang", "Li", "Zhang", "Fen", "Lin"};

  char last_names[][24] = 
   {"Chen", "Yang", "Zhao", "Huang", "Brown", "Black", "Smith", "Williams", 
    "Jones", "Miller", "Johnson", "Davis", "Abbas", "Ali", "Bakir", "Ismat", 
    "Khalid", "Wahed", "Taleb", "Hafeez", "Hadid", "Lopez", "Gonzalez", "Moore"};
 
  Student *new_student = calloc(1, sizeof(Student));  //dynamically allocate space for one student 

  //generate random first name and last name for student
  strcpy(new_student->first_name, first_names[rand() % 24]);
  strcpy(new_student->last_name, last_names[rand() % 24]);

  for (int i = 0; i < 10; i++) new_student->id[i] = (char) ((rand() % 10) + 48);  //for loop generates an id for the new student
  new_student->id[10] = '\0';

  // for loop generates random grades for the student
  for (int i = 0; i < grades; i++) 
  {
    add_grade(new_student, (double) (25 + (rand() % 75)));
  }

  return new_student;
}